﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UI3
{
    public partial class Form1 : Form
    {
        public Control[][] ct;
        public Form1()
        {
            InitializeComponent();
            this.textBox1.Focus();
            ct = new Control[][]{
                new Control[]{textBox1, comboBox1},
                new Control[]{listBox1,dateTimePicker1},
                new Control[]{textBox2,textBox3}
             };
        }
        private void button3_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog()==DialogResult.OK)
            {
                textBox1.Font = fd.Font;
                textBox2.Font = fd.Font;
                comboBox1.Font = fd.Font;
                listBox1.Font = fd.Font;
                dateTimePicker1.CalendarFont = fd.Font;
                dateTimePicker1.Font = fd.Font;
                textBox3.Font = fd.Font;
               
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                textBox1.ForeColor = cd.Color;
                textBox2.ForeColor = cd.Color;
                textBox3.ForeColor = cd.Color;
                comboBox1.ForeColor = cd.Color;
                listBox1.ForeColor = cd.Color;
                dateTimePicker1.CalendarTitleForeColor = cd.Color;
                dateTimePicker1.CalendarForeColor = cd.Color;
                
               
               
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            comboBox1.Text = null;
            radioButton2.Checked = true;
            radioButton1.Checked = false;
            checkBox1.Checked = true;
            checkBox2.Checked = true;
            checkBox3.Checked = true;
            checkBox4.Checked = true;   
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 myf2 = new Form2();
            
            myf2.setlabel1(this.textBox1.Text);
            myf2.ShowDialog();
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)//切换焦点
        {
 
            int i = 0;
            int j = 0;
            int k = 0;
            int flag=0;
            for (i = 0; i < this.Controls.Count; i++)
            {
                if (this.Controls[i].Focused)
                    break;
            }
            for (j = 0; j < 3; j++)
            {
                for (k = 0; k < 2; k++)
                {
                    if (this.Controls[i] == ct[j][k])
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 1)
                    break;
            }
           
            if (e.KeyCode == Keys.Up)
            {
               
                   j=(j-1+3)%3;
                ct[j][k].Focus();
            }
            if (e.KeyCode == Keys.Down)
            {
                j = (j + 1) % 3;
                ct[j][k].Focus();
            }
            if (e.KeyCode == ( Keys.Left|Keys.Control))
            {
               
                k = (k - 1+2) % 2;
                ct[j][k].Focus();
            }
            if (e.KeyCode == ( Keys.Right|Keys.Control))
            {
                k=(k+1)%2;
                ct[j][k].Focus();
            }
        }
    }
}
