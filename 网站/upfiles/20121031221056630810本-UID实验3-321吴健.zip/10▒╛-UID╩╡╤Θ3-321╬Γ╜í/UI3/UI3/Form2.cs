﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UI3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public void setlabel1(string a)
        {
            this.label1.Text = a;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.Font = fd.Font;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.ForeColor = cd.Color;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = null;
            richTextBox1.ForeColor = Color.Black;
            richTextBox1.Font = Font;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 mf3 = new Form3();
            mf3.ShowDialog();
        }
    }
}
