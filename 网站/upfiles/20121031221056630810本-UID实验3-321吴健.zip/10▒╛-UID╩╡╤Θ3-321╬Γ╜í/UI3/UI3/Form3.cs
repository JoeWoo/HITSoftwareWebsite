﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace UI3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            progressBar1.Value = 10;
            progressBar1.Value = 100;
            label1.Text = "发布完成！";   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       
    }
}
